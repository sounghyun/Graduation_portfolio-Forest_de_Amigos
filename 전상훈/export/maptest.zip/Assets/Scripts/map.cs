﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class map : MonoBehaviour {

    public GameObject hexPrefab;


    
    int width = 60;
    int height = 60;

    float xOffset = 0.882f;
    float zOffset = 0.764f;

	// Use this for initialization
	void Start () {
		for(int x = 0; x < width; x++)
        {
            for(int y = 0; y < height; y++)
            {
                float xPos = x *xOffset;
                if (y % 2 == 1)
                {
                    xPos += xOffset/2f;
                }
                //if(y % 2 == 0)
                GameObject hex_pos = (GameObject)Instantiate(hexPrefab, new Vector3(xPos, 0, y * zOffset), Quaternion.identity);


                hex_pos.name = "HEX_" + x + "_" + y;

                hex_pos.transform.SetParent(this.transform);
            }
        }
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
